# python2 and python3 supported
from __future__ import division, print_function, unicode_literals

import warnings

# import package
import pandas as pd
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
from sklearn.externals import joblib

warnings.filterwarnings("ignore")

############################################## parameters ##############################################
"""
You can change the following parameters as you need.


Parameters
--------------
filename: str
    Filename of the dataset for predicting.
suffix: str
    The file type of the dataset.
used_model: str
    The model used to predict.    
degree:
    The degree of the polynomial in 'used_model'.   
    Make sure that the degree should be the same with that used in the optimization model obtained from MPR_TRIAN. 
"""
filename = "UN-dataset"
suffix = ".xlsx"
used_model = "MPR.pkl"
degree = 3
############################################## code ##############################################
if __name__ == '__main__':
    # read data and drop useless column
    df = pd.read_excel(filename + suffix)
    df_bak = df.copy()

    if 'Number' in df.columns:
        df = df.drop("Number", axis=1)

    poly_features = PolynomialFeatures(degree=degree, include_bias=False)
    df_poly = poly_features.fit_transform(df)
    MPR = joblib.load(used_model)
    y_pred = MPR.predict(df_poly)

    # fill NaN values and values less than 0
    y_pred[y_pred < 0] = 0
    y_pred[np.isnan(y_pred)] = 0

    df_bak['Li2O-pred'] = y_pred
    outputname = filename + '_degree_' + str(degree) + '_prediction_result.xlsx'
    df_bak.to_excel(outputname, index=False)
