********************************************** 
 
Version: Python 3.7.6 
IDE: PyCharm

**********************************************

Library:
numpy, pandas, matplolib, sklearn

Function：
MPR_TRAIN.py reads the training set to train the polynomial model.
MPR_PREDICT.py can apply the trained model to the unknown dataset to predict the Li2O content.

Data Set：
final-dataset1.xlsx: The dataset for training and testing.
UN-dataset.xlsx: The unkown dataset to be predicted.

Output File:
final-dataset1_random_1234_degree_3_regularized_polynomial_TP.png: Comparison of the true and predicted values in training and test sets.
final-dataset1_random_1234_degree_3_testset_prediction_result.xlsx: The predicted result of the test set.
final-dataset1_random_1234_degree_3_trainset_prediction_result.xlsx: The predicted result of the training set.
MPR.pkl: The optimization model after training. It is used in the MPR_PREDICT.py.
final-dataset1_random_1234_model.txt: The coefficients, intercept and powers of the optimization model. 
UN-dataset_degree_3_prediction_result.xlsx: The predicted result of the unknown dataset.

Notice:
The input datasets should not have NaN values.
If the polynomial degree equals 3 or higher, it would take a long time for training.
*********************************************

