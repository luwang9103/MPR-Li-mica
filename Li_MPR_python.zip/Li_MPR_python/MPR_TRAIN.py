# python2 and python3 supported
from __future__ import division, print_function, unicode_literals

# import package
import os
import warnings
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.pyplot import MultipleLocator
from sklearn.externals import joblib
from sklearn.linear_model import ElasticNet
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures

warnings.filterwarnings("ignore")

############################################## parameters ##############################################
'''
You can change the following parameters as you need. 


Parameters
--------------
random_state: int
    Random seed used to divide dataset into training set and test set.
filename: str
    Filename of the training dataset.
degree: int
    The degree of the polynomial.
suffix: str
    The file type of the dataset.
image_dir: str
    The root path to which the image is saved.
output_model: str
     Name of the optimization model.
test_size: float
     Proportion of data used for testing.
'''
random_state = 1234
filename = "final-dataset1"
degree = 3
suffix = ".xlsx"
image_dir = "."
output_model = "MPR.pkl"
test_size = 0.3


############################################## code ##############################################
def save_fig(fig_id, image_dir=image_dir, tight_layout=True):
    """
    The function to save figure.

    Parameters
    ------------------------------------------
    fig_id: str
        The id for figure to be saved.
    image_dir: str
        The root path to which the image is saved.
    tight_layout: str
        Automatically adjust subplot parameters to give specified padding,
        Optional, the default value is Ture.
    """
    path = os.path.join(image_dir, fig_id + ".png")
    print("Saving figure", fig_id)
    if tight_layout:
        plt.tight_layout()
    plt.savefig(path, format='png', dpi=300)


def plot_fig(train_labels, test_labels, train_pre_labels, test_pre_labels,
             train_RMSE, test_RMSE, train_R2, test_R2):
    """
    The function to plot figure.

    Parameters
    ------------------------------------------
    train_labels: array
        Labels value in train set.
    test_labels: array
        Labels value in test set.
    train_pre_labels: array
        The predicted value of the training set.
    test_pre_labels: array
        The predicted value of the test set.
    train_RMSE: float
        RMSE(Root Mean Square Error) of the training set
    test_RMSE: float
        RMSE(Root Mean Square Error) of the test set
    train_R2: float
        R^2 (coefficient of determination) of the training set.
    test_R2: float
        R^2 (coefficient of determination) of the test set.
    """
    plt.scatter(train_labels, train_pre_labels, c='#00CED1', label='Train Dataset')
    plt.scatter(test_labels, test_pre_labels, c='#DC143C', label='Test Dataset')

    plt.legend()
    plt.xlabel("True Value")
    plt.ylabel("Prediction")
    plt.title("TRAIN SET: RMSE: %s and R2: %s\nTEST SET: RMSE: %s and R2: %s"
              % (round(train_RMSE, 2), round(train_R2, 2), round(test_RMSE, 2), round(test_R2, 2)))
    a = [0, 8]
    b = [0, 8]
    plt.plot(a, b, 'r')
    plt.plot(a, b - test_RMSE, '-.k')
    plt.plot(a, b + test_RMSE, '-.k')

    # Set the scale interval on the x axis to 1
    x_major_locator = MultipleLocator(1)
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)

    outputname = filename + '_random_' + \
                 str(random_state) + '_degree_' + \
                 str(degree) + '_regularized_polynomial_TP'
    save_fig(outputname)


if __name__ == '__main__':
    # read data and drop useless column
    df = pd.read_excel(filename + suffix)

    if 'Number' in df.columns:
        df_edit = df.drop("Number", axis=1)
    else:
        df_edit = df

    # the dataset is divided into test set and training set by pure random sampling,
    # where the ratio of the test set is 0.3
    train_set, test_set = train_test_split(
        df_edit, test_size=test_size, random_state=random_state)

    major_el_train_rd = train_set.drop("Li2O", axis=1)
    major_el_train_labels = train_set["Li2O"].copy()
    major_el_test_rd = test_set.drop("Li2O", axis=1)
    major_el_test_labels = test_set["Li2O"].copy()

    # make the power of each feature in the training set as the new feature to get the extended feature set
    poly_features = PolynomialFeatures(degree=degree, include_bias=False)
    major_el_train_rd_poly = poly_features.fit_transform(major_el_train_rd)
    major_el_test_rd_poly = poly_features.fit_transform(major_el_test_rd)

    # Find the optimal alpha value and L1 ratio
    alphas = [i / 10 for i in range(1, 11)]
    l1_ratios = [i / 10 for i in range(1, 11)]
    elastic_net = ElasticNet(max_iter=100000, tol=0.0005)

    train_R2_scores = list()

    for alpha in alphas:
        for l1_ratio in l1_ratios:
            elastic_net.set_params(alpha=alpha, l1_ratio=l1_ratio)
            elastic_net.fit(major_el_train_rd_poly, major_el_train_labels)
            train_R2_scores.append(elastic_net.score(
                major_el_train_rd_poly, major_el_train_labels))

    index_optim = np.argmax(train_R2_scores)
    alpha_optim = alphas[int(index_optim / 10)]
    l1_ratio_optim = l1_ratios[int(index_optim % 10)]

    # regularize polynomial regression with elastic network,
    # which is equivalent to a simple mixture of Ridge regression and Lasso regression
    elastic_net = ElasticNet(
        alpha=alpha_optim, l1_ratio=l1_ratio_optim, max_iter=100000, tol=0.0005)
    elastic_net.fit(major_el_train_rd_poly, major_el_train_labels)

    # predicted value of training and test sets
    major_el_elastic_train_rd_pre = elastic_net.predict(major_el_train_rd_poly)
    major_el_elastic_test_rd_pre = elastic_net.predict(major_el_test_rd_poly)

    # training dataset
    train_true_labels = np.array(major_el_train_labels)
    train_regularized_polynomial_pre_label = major_el_elastic_train_rd_pre

    # test dataset
    test_true_labels = np.array(major_el_test_labels)
    test_regularized_polynomial_pre_label = major_el_elastic_test_rd_pre

    # fill values less than 0
    train_regularized_polynomial_pre_label[train_regularized_polynomial_pre_label < 0] = 0
    test_regularized_polynomial_pre_label[test_regularized_polynomial_pre_label < 0] = 0

    # get RMSE and r2 in training set
    train_regularized_polynomial_RMSE = np.sqrt(
        mean_squared_error(train_true_labels, train_regularized_polynomial_pre_label))
    train_regularized_polynomial_R2 = r2_score(train_true_labels, train_regularized_polynomial_pre_label)

    print("training set RMSE：", train_regularized_polynomial_RMSE)
    print("training set R2：", train_regularized_polynomial_R2)

    # get RMSE and r2 in test set
    test_regularized_polynomial_RMSE = np.sqrt(mean_squared_error(
        test_true_labels, test_regularized_polynomial_pre_label))
    test_regularized_polynomial_R2 = r2_score(
        test_true_labels, test_regularized_polynomial_pre_label)

    print("test set RMSE：", test_regularized_polynomial_RMSE)
    print("test set R2：", test_regularized_polynomial_R2)

    # plot and save figure
    plot_fig(train_true_labels, test_true_labels,
             train_regularized_polynomial_pre_label, test_regularized_polynomial_pre_label,
             train_regularized_polynomial_RMSE, test_regularized_polynomial_RMSE,
             train_regularized_polynomial_R2, test_regularized_polynomial_R2)

    # output prediction in training and test sets
    train_set['regularized_polynomial_pre'] = train_regularized_polynomial_pre_label
    outputname = filename + '_random_' + str(random_state) + '_degree_' + str(
        degree) + '_trainset_prediction_result.xlsx'
    train_set.to_excel(outputname, index=True)
    test_set['regularized_polynomial_pre'] = test_regularized_polynomial_pre_label
    outputname = filename + '_random_' + str(random_state) + '_degree_' + str(
        degree) + '_testset_prediction_result.xlsx'
    test_set.to_excel(outputname, index=True)

    # output the parameters of the regular polynomial model
    np.set_printoptions(threshold=np.inf)  # make sure the complete output of the Numpy array
    outputname = filename + '_random_' + str(random_state) + '_model.txt'
    file = open(outputname, 'w')
    file.write('coef:\n' + str(elastic_net.coef_));
    file.write('\nintercept:\n' + str(elastic_net.intercept_));
    file.write('\npowers:\n' + str(poly_features.powers_));
    file.close()

    # save model
    joblib.dump(elastic_net, output_model)
